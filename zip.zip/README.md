
# CS04 PETHUB

A brief description of what this project does and who it's for




## Tech Stack

**Client:** React, Material UI, Bhalloo BhaiJan, Stripe

**Server:** Node, Express, Firebase, Multer, Stripe, ByCript-JS


## Features

- Pet Manager
- Shop
- Adoption Portal
- Community

